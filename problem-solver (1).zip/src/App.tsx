/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import ReactMarkdown from 'react-markdown';
import { Upload, Search, Loader2, AlertTriangle, X, Copy, Check, Star } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function App() {
  const [prompt, setPrompt] = useState('');
  const [image, setImage] = useState<File | null>(null);
  const [result, setResult] = useState('');
  const [copied, setCopied] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [rating, setRating] = useState(0);

  const copyToClipboard = () => {
    navigator.clipboard.writeText(result);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setImage(e.target.files[0]);
    }
  };

  const handleSubmit = async () => {
    if (!prompt && !image) return;
    setLoading(true);
    setError(null);
    setResult('');
    setRating(0);

    try {
      let base64Image = null;
      if (image) {
        const reader = new FileReader();
        base64Image = await new Promise<string>((resolve) => {
          reader.onload = () => resolve(reader.result as string);
          reader.readAsDataURL(image);
        });
      }
      
      const response = await fetch("/api/solve", {
          method: "POST",
          headers: {
              "Content-Type": "application/json",
          },
          body: JSON.stringify({ 
              prompt, 
              image: base64Image ? base64Image.split(',')[1] : null,
              mimeType: image?.type
          }),
      });

      if (!response.ok) {
        throw new Error('Failed to solve problem.');
      }

      const data = await response.json();
      setResult(data.text);
      
      setPrompt('');
      setImage(null);
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'An unexpected error occurred.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <motion.div 
      initial={{ backgroundPosition: '0% 0%' }}
      animate={{ backgroundPosition: ['0% 0%', '100% 100%'] }}
      transition={{ duration: 20, repeat: Infinity, repeatType: 'reverse' }}
      className="min-h-screen p-4 md:p-8 font-sans bg-gradient-to-br from-indigo-950 via-slate-950 to-gray-950 text-white"
      style={{ backgroundSize: '200% 200%' }}
    >
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-3xl mx-auto"
      >
        <header className="mb-8 text-center">
            <h1 className="text-4xl font-extrabold tracking-tight">Problem Solver</h1>
            <p className="text-gray-400 mt-2">Verified solutions. Real-world insights.</p>
        </header>
        
        <div className="bg-white/10 backdrop-blur-md p-6 rounded-2xl shadow-xl border border-white/10 mb-8">
          <textarea
            className="w-full p-4 border border-white/10 bg-white/5 rounded-xl mb-4 focus:ring-2 focus:ring-blue-500 transition text-white placeholder-gray-400"
            placeholder="Describe your problem clearly..."
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            rows={4}
          />
          
          <div className="flex items-center gap-4 mb-4">
            <label className="flex items-center gap-2 px-4 py-2 bg-white/5 rounded-lg cursor-pointer hover:bg-white/10 transition text-gray-200">
              <Upload size={18} />
              <span className='text-sm'>{image ? image.name : 'Upload Image'}</span>
              <input type="file" className="hidden" onChange={handleFileChange} accept="image/*" />
            </label>
            {image && <button onClick={() => setImage(null)} className='text-red-400'><X size={18}/></button>}
            
            <button
              onClick={handleSubmit}
              disabled={loading || (!prompt && !image)}
              className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition flex items-center gap-2 disabled:opacity-50 ml-auto font-medium"
            >
              {loading ? <><Loader2 className="animate-spin" size={18} /> Solving...</> : <><Search size={18} /> Solve Problem</>}
            </button>
          </div>
          
          {error && <motion.div initial={{opacity:0}} animate={{opacity:1}} className="text-red-400 flex items-center gap-2 mt-2 bg-red-950/20 p-3 rounded-lg"><AlertTriangle size={18} />{error}</motion.div>}
        </div>

        <AnimatePresence>
        {result && (
          <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="bg-white/10 backdrop-blur-md p-8 rounded-2xl shadow-xl border border-white/10"
          >
            <div className='flex justify-between items-center mb-6'>
                <h2 className="text-2xl font-bold">Solution:</h2>
                <button onClick={copyToClipboard} className='text-gray-400 hover:text-blue-400 flex items-center gap-1 text-sm transition'>
                  {copied ? <><Check size={16}/> Copied</> : <><Copy size={16}/> Copy</>}
                </button>
            </div>
            <div className="prose prose-invert max-w-none">
              <ReactMarkdown>{result}</ReactMarkdown>
            </div>
            <div className='flex items-center gap-1 mt-6 border-t border-white/10 pt-4'>
              <span className='text-sm text-gray-400 mr-2'>Rate the solution:</span>
              {[1, 2, 3, 4, 5].map((star) => (
                <Star
                  key={star}
                  size={20}
                  className={`cursor-pointer transition ${star <= rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-500'}`}
                  onClick={() => setRating(star)}
                />
              ))}
            </div>
          </motion.div>
        )}
        </AnimatePresence>
        
        <footer className="mt-12 text-center p-6 border-t border-white/10">
          <p className="text-lg font-serif italic text-gray-300">
            Developed by <span className="font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-indigo-400">Kingmaster</span>
          </p>
          <p className="text-sm text-gray-500 mt-1">WhatsApp: +255623442390</p>
        </footer>
      </motion.div>
    </motion.div>
  );
}
